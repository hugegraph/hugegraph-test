//schema.propertyKey('nName').asInt().ifNotExist().create();
// schema.vertexLabel('node').useCustomizeNumberId().properties('nName').ifNotExist().create();
schema.vertexLabel('node').useCustomizeNumberId().ifNotExist().create();
schema.edgeLabel('link').sourceLabel('node').targetLabel('node').ifNotExist().create();
