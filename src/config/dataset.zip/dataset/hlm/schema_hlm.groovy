schema.propertyKey('姓名').asText().ifNotExist().create();
schema.propertyKey('性别').asText().ifNotExist().create();
schema.propertyKey('年龄').asInt().ifNotExist().create();
schema.propertyKey('职称').asText().ifNotExist().create();
schema.propertyKey('特点').asText().ifNotExist().create();
schema.propertyKey('亲疏').asText().ifNotExist().create();


schema.vertexLabel('人物').properties('姓名', '性别', '年龄', '职称', '特点').useCustomizeStringId().ifNotExist().create();

schema.edgeLabel('关系').sourceLabel('人物').targetLabel('人物').properties("亲疏").ifNotExist().create();