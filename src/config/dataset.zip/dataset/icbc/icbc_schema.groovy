schema.propertyKey("Party_Name").asText().ifNotExist().create();
schema.propertyKey("Int_Org_Num").asText().ifNotExist().create();
schema.propertyKey("Org_Num_Level").asText().ifNotExist().create();
schema.propertyKey("Int_Org_Num_Nm").asText().ifNotExist().create();
schema.propertyKey("Int_Org_Num_Probranch").asText().ifNotExist().create();
schema.propertyKey("Int_Org_Num_Branch").asText().ifNotExist().create();
schema.propertyKey("Int_Org_Num_Subbranch").asText().ifNotExist().create();
schema.propertyKey("Brno").asText().ifNotExist().create();
schema.propertyKey("Zoneno").asText().ifNotExist().create();
schema.propertyKey("PC_Flag").asText().ifNotExist().create();
schema.propertyKey("Icbc_Flag").asText().ifNotExist().create();
schema.propertyKey("REGTYPE").asDouble().ifNotExist().create();
schema.propertyKey("REGNO").asText().ifNotExist().create();
schema.propertyKey("ACCOUNT").asText().ifNotExist().create();
schema.propertyKey("ACCOUNT_BELONG").asText().ifNotExist().create();
schema.propertyKey("MOBILE").asText().ifNotExist().create();
schema.propertyKey("WORKPLACE").asText().ifNotExist().create();


schema.propertyKey("EDGE_ID").asText().ifNotExist().create();
schema.propertyKey("Flow_Type").asText().ifNotExist().create();
schema.propertyKey("tx_amt").asDouble().ifNotExist().create();
schema.propertyKey("tx_cnt").asDouble().ifNotExist().create();
schema.propertyKey("In_Rank_Id_Amt").asDouble().ifNotExist().create();
schema.propertyKey("Out_Rank_Id_Amt").asDouble().ifNotExist().create();
schema.propertyKey("s_flag").asText().ifNotExist().create();
schema.propertyKey("date_dt").asText().ifNotExist().create();
schema.propertyKey("date").asText().ifNotExist().create();


schema.vertexLabel("PERSON_CUST").properties("Party_Name", "Int_Org_Num", "Org_Num_Level","Int_Org_Num_Nm", "Int_Org_Num_Probranch","Int_Org_Num_Branch", "Int_Org_Num_Subbranch","Brno","Zoneno","PC_Flag","Icbc_Flag","REGTYPE","REGNO","ACCOUNT","ACCOUNT_BELONG","MOBILE","WORKPLACE").useCustomizeStringId().enableLabelIndex(false).ifNotExist().create();

schema.edgeLabel("CUST_PTHSJNL_MONTHFLOW").sourceLabel("PERSON_CUST").targetLabel("PERSON_CUST").properties("EDGE_ID","Flow_Type","tx_amt","tx_cnt","In_Rank_Id_Amt","Out_Rank_Id_Amt","s_flag","date_dt","date").multiTimes().sortKeys("EDGE_ID","date_dt").enableLabelIndex(false).ifNotExist().create()