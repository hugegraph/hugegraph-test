// 电影属性
schema.propertyKey("名称").asText().ifNotExist().create();
schema.propertyKey("类型").asText().ifNotExist().create();
schema.propertyKey("发行时间").asDate().ifNotExist().create();

// 演出角色
schema.propertyKey("演员").asText().ifNotExist().create();

// 电影
schema.vertexLabel("电影")
      .properties("名称","类型","发行时间")
      .primaryKeys("名称")
      .ifNotExist().create();
// 艺人
schema.vertexLabel("艺人").properties("演员").primaryKeys("演员").ifNotExist().create();
// 类型
schema.vertexLabel("类型").properties("类型").primaryKeys("类型").ifNotExist().create();
// 年份
schema.vertexLabel("年份").properties("发行时间").primaryKeys("发行时间").ifNotExist().create();

// 导演: 艺人 -> 电影
schema.edgeLabel("导演").link("艺人","电影").ifNotExist().create();
// 演出: 艺人 -> 电影
schema.edgeLabel("演出").link("艺人","电影").ifNotExist().create();
// 属于: 电影 -> 类型
schema.edgeLabel("属于").link("电影","类型").properties("发行时间").ifNotExist().create();
// 发行于: 电影 -> 年份
schema.edgeLabel("发行于").link("电影","年份").properties("发行时间").ifNotExist().create();
